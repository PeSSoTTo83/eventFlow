package com.eventFlow.repository;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Usuario;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EventoRepository extends JpaRepository<Evento, Long> {
	List<Evento> findByCreadorEmail(String email);
//	List<Evento> findByParticipantesContaining(Usuario usuario);
	List<Evento> findByEstadoEvento(String estadoEvento);

}
