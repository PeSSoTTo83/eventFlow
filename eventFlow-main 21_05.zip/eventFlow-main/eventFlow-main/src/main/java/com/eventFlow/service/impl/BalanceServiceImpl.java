package com.eventFlow.service.impl;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Gasto;
import com.eventFlow.model.Patrocinador;
import com.eventFlow.model.Participante;
import com.eventFlow.repository.ParticipanteRepository;
import com.eventFlow.service.BalanceService;
import com.eventFlow.service.GastoService;
import com.eventFlow.service.PatrocinadorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BalanceServiceImpl implements BalanceService {

    @Autowired
    private PatrocinadorService patrocinadorService;

    @Autowired
    private GastoService gastoService;

    @Autowired
    private ParticipanteRepository participanteRepository; // ✅ Añadir esto

    @Override
    public Double calcularIngresos(Evento evento) {
        // ✅ Obtener participantes reales del evento
        List<Participante> participantes = participanteRepository.findByEvento(evento);
        double precio = evento.getPrecioInscripcion() != null ? evento.getPrecioInscripcion() : 0.0;
        double ingresosInscripciones = participantes.size() * precio;

        // ✅ Sumar patrocinadores del evento
        double totalPatrocinio = patrocinadorService.listarTodos().stream()
                .filter(p -> p.getEvento().getIdEvento().equals(evento.getIdEvento()))
                .mapToDouble(Patrocinador::getImportePatrocinio)
                .sum();

        return ingresosInscripciones + totalPatrocinio;
    }

    @Override
    public Double calcularGastos(Evento evento) {
        List<Gasto> gastos = gastoService.listarPorEvento(evento.getIdEvento());
        return gastos.stream().mapToDouble(Gasto::getImporte).sum();
    }

    @Override
    public Double calcularBalance(Evento evento) {
        return calcularIngresos(evento) - calcularGastos(evento);
    }
}
