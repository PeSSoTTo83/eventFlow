package com.eventFlow.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.eventFlow.model.ClasificacionGeneral;
import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.EnfrentamientoParticipante1vs1;
import com.eventFlow.model.EnfrentamientoParticipante2vs2;
import com.eventFlow.model.Evento;
import com.eventFlow.repository.ClasificacionGeneralRepository;
import com.eventFlow.repository.ClubRepository;
import com.eventFlow.repository.Enfrentamiento1vs1Repository;
import com.eventFlow.repository.Enfrentamiento2vs2Repository;
import com.eventFlow.repository.EnfrentamientoClubVsClubRepository;
import com.eventFlow.repository.ParticipanteRepository;
import com.eventFlow.service.EventoService;

@Controller
@RequestMapping("/clasificaciones-participante")
public class ClasificacionParticipanteController {


    @Autowired
    private EventoService eventoService;

    @Autowired
    private ClasificacionGeneralRepository clasificacionGeneralRepo;

    @Autowired
    private ParticipanteRepository participanteRepo;
    

    @Autowired
    private Enfrentamiento1vs1Repository enfrentamientoRepo;
    
    @Autowired
    private Enfrentamiento2vs2Repository enfrentamiento2vs2Repo;
    
    @Autowired
    private EnfrentamientoClubVsClubRepository enfrentamientoClubRepo;

    @Autowired
    private ClubRepository clubRepo;
   

    @GetMapping
    public String mostrarEventosParticipante(Model model, Principal principal) {

        String email = principal.getName();
        List<Evento> eventos = eventoService.obtenerEventosDeParticipante(email);
        model.addAttribute("eventos", eventos);
        return "clasificaciones_participante_eventos";
    }

    @GetMapping("/general/{eventoId}")
    public String verClasificacionGeneral(@PathVariable Long eventoId, Principal principal, Model model) {
        Evento evento = eventoService.buscarPorId(eventoId);
        List<ClasificacionGeneral> clasificados = clasificacionGeneralRepo.findByEvento(evento);
        model.addAttribute("evento", evento);
        model.addAttribute("clasificados", clasificados);
        return "clasificaciones_participante_general";
    }
    
    @PostMapping("/seleccionar-evento")
    public String redirigirDesdeSelector(@RequestParam Long eventoId) {
        Evento evento = eventoService.buscarPorId(eventoId);
        if (evento != null && evento.getTipoClasificacion() != null) {
            String tipo = evento.getTipoClasificacion().getNombre();
            if ("General".equalsIgnoreCase(tipo)) {
                return "redirect:/clasificaciones-participante/general/" + eventoId;
            }
            if ("Versus".equalsIgnoreCase(tipo) && evento.getTipoVersus() != null) {
                String subtipo = evento.getTipoVersus().getNombre().toLowerCase().replace(" ", "-");
                return "redirect:/clasificaciones-participante/versus-" + subtipo + "/" + eventoId;
            }
        }
        return "redirect:/clasificaciones-participante";
    }

    @GetMapping("/versus-1vs1/{id}")
    public String mostrarVersus1vs1(@PathVariable Long id, Model model) {
        Evento evento = eventoService.buscarPorId(id);
        List<EnfrentamientoParticipante1vs1> enfrentamientos = enfrentamientoRepo.findByEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("enfrentamientos", enfrentamientos);
        return "versus_1vs1_participante";
    }

    @GetMapping("/versus-2vs2/{id}")
    public String mostrarVersus2vs2Participante(@PathVariable Long id, Model model) {
        Evento evento = eventoService.buscarPorId(id);
        if (evento == null) return "redirect:/clasificaciones-participante";

        List<EnfrentamientoParticipante2vs2> enfrentamientos = enfrentamiento2vs2Repo.findByEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("enfrentamientos", enfrentamientos);
        return "versus_2vs2_participante";
    }
    
    @GetMapping("/club-vs-club/{id}")
    public String verClubVsClub(@PathVariable Long id, Model model) {
        Evento evento = eventoService.buscarPorId(id);
        List<EnfrentamientoClubVsClub> enfrentamientos = enfrentamientoClubRepo.findByEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("enfrentamientos", enfrentamientos);
        return "versus_clubvsclub_participante";
    }

}

