package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Gasto;
import com.eventFlow.repository.EventoRepository;
import com.eventFlow.repository.GastoRepository;
import com.eventFlow.repository.PatrocinadorRepository;
import com.eventFlow.service.BalanceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/balanceorganizador")
public class BalanceOrganizadorController {

    @Autowired
    private EventoRepository eventoRepo;

    @Autowired
    private GastoRepository gastoRepo;

    @Autowired
    private PatrocinadorRepository patrocinadorRepo;

    @Autowired
    private BalanceService balanceService;

    /**
     * Muestra la vista para seleccionar un evento del organizador.
     */
    @GetMapping
    public String seleccionarEvento(Model model, Principal principal) {
        String email = principal.getName();
        List<Evento> eventos = eventoRepo.findByCreadorEmail(email);
        model.addAttribute("eventos", eventos);
        return "seleccionar_evento_balance_organizador";
    }

    /**
     * Redirige tras seleccionar un evento desde el formulario.
     */
    @PostMapping("/seleccionar-evento")
    public String redirigirDesdeSelector(@RequestParam("eventoId") Long eventoId) {
        return "redirect:/balanceorganizador/evento/" + eventoId;
    }

    /**
     * Muestra el balance financiero del evento seleccionado.
     */
    @GetMapping("/evento/{id}")
    public String verBalance(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/balanceorganizador";

        prepararModeloBalance(model, evento);
        model.addAttribute("nuevoGasto", new Gasto());

        return "balance_organizador";
    }

    /**
     * Guarda un nuevo gasto para el evento.
     */
    @PostMapping("/guardar/{id}")
    public String guardarGasto(@PathVariable Long id, @ModelAttribute Gasto nuevoGasto) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento != null) {
            nuevoGasto.setEvento(evento);
            gastoRepo.save(nuevoGasto);
        }
        return "redirect:/balanceorganizador/evento/" + id;
    }

    /**
     * Muestra el formulario de edición para un gasto existente.
     */
    @GetMapping("/editar/{idGasto}/{idEvento}")
    public String editarGasto(@PathVariable Long idGasto, @PathVariable Long idEvento, Model model) {
        Evento evento = eventoRepo.findById(idEvento).orElse(null);
        Gasto gasto = gastoRepo.findById(idGasto).orElse(null);
        if (evento == null || gasto == null) return "redirect:/balanceorganizador";

        prepararModeloBalance(model, evento);
        model.addAttribute("editando", gasto);

        return "balance_organizador";
    }

    /**
     * Actualiza un gasto existente.
     */
    @PostMapping("/update/{id}")
    public String actualizarGasto(@PathVariable Long id, @ModelAttribute Gasto editando) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento != null) {
            editando.setEvento(evento);
            gastoRepo.save(editando);
        }
        return "redirect:/balanceorganizador/evento/" + id;
    }

    /**
     * Elimina un gasto del evento.
     */
    @GetMapping("/eliminar/{idGasto}/{idEvento}")
    public String eliminarGasto(@PathVariable Long idGasto, @PathVariable Long idEvento) {
        gastoRepo.deleteById(idGasto);
        return "redirect:/balanceorganizador/evento/" + idEvento;
    }

    /**
     * Prepara los datos comunes del modelo para las vistas de balance.
     */
    private void prepararModeloBalance(Model model, Evento evento) {
        model.addAttribute("evento", evento);
        model.addAttribute("ingresos", balanceService.calcularIngresos(evento));
        model.addAttribute("gastos", balanceService.calcularGastos(evento));
        model.addAttribute("balance", balanceService.calcularBalance(evento));
        model.addAttribute("gastosLista", gastoRepo.findByEvento(evento));
    }
}
