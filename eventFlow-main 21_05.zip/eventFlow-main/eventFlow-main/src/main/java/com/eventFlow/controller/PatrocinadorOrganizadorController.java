package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Patrocinador;
import com.eventFlow.repository.EventoRepository;
import com.eventFlow.repository.PatrocinadorRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/patrocinadoresorganizador")
public class PatrocinadorOrganizadorController {

    @Autowired
    private EventoRepository eventoRepo;

    @Autowired
    private PatrocinadorRepository patrocinadorRepo;

    // 1. Selección de evento por el organizador
    @GetMapping
    public String mostrarEventos(Principal principal, Model model) {
        String email = principal.getName();
        List<Evento> eventos = eventoRepo.findByCreadorEmail(email);
        model.addAttribute("eventos", eventos);
        return "seleccionar_evento_patrocinador_organizador"; // VISTA ACTUALIZADA
    }

    // 2. Mostrar los patrocinadores del evento
    @GetMapping("/{id}")
    public String mostrarPatrocinadoresPorEvento(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/patrocinadoresorganizador";

        List<Patrocinador> patrocinadores = patrocinadorRepo.findByEvento(evento);
        model.addAttribute("evento", evento);
        model.addAttribute("patrocinadores", patrocinadores);
        model.addAttribute("patrocinador", new Patrocinador());
        return "patrocinadores_organizador"; // VISTA ACTUALIZADA
    }

    // 3. Guardar o actualizar un patrocinador
    @PostMapping("/guardar/{eventoId}")
    public String guardarPatrocinador(@PathVariable Long eventoId,
                                      @ModelAttribute Patrocinador patrocinador) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        if (evento != null) {
            patrocinador.setEvento(evento);
            patrocinadorRepo.save(patrocinador);
        }
        return "redirect:/patrocinadoresorganizador/" + eventoId;
    }

    // 4. Editar un patrocinador
    @GetMapping("/editar/{id}")
    public String editarPatrocinador(@PathVariable Long id, Model model) {
        Patrocinador patrocinador = patrocinadorRepo.findById(id).orElse(null);
        if (patrocinador == null) return "redirect:/patrocinadoresorganizador";

        Evento evento = patrocinador.getEvento();
        List<Patrocinador> patrocinadores = patrocinadorRepo.findByEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("patrocinadores", patrocinadores);
        model.addAttribute("patrocinador", patrocinador);
        return "patrocinadores_organizador"; // VISTA ACTUALIZADA
    }

    // 5. Eliminar un patrocinador
    @GetMapping("/eliminar/{id}")
    public String eliminarPatrocinador(@PathVariable Long id) {
        Patrocinador patrocinador = patrocinadorRepo.findById(id).orElse(null);
        if (patrocinador != null) {
            Long eventoId = patrocinador.getEvento().getIdEvento();
            patrocinadorRepo.deleteById(id);
            return "redirect:/patrocinadoresorganizador/" + eventoId + "?eliminado=true";
        }
        return "redirect:/patrocinadoresorganizador";
    }
    
    @PostMapping("/seleccionar-evento")
    public String redirigirDesdeSelector(@RequestParam("eventoId") Long eventoId) {
        return "redirect:/patrocinadoresorganizador/" + eventoId;
    }

}
