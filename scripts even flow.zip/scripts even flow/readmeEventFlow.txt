1. En MySQL crear base de datos event_flow a mano.
2. Corroborar que en el properties del programa en Springboot Tools Suite la base de datos esta en localhost:3306 (MySQL), y la base de datos se llama event_flow.
	- En la carpeta src\main\resources. 
	- spring.datasource.url=jdbc:mysql://localhost:3306/event_flow
3. Runear el programa desde el main, Spring Boot App.
		- src\main\java.
		- com.eventFlow.
		- EventFlowAplication.java
		- Boton derecha encima. 
		- Run as -> Spring Boot App
4. Cargar el script en MySQL: script_relleno_tipos.
5. Cargar el script en MySQL: script_admin_compAseg_feder_club_local_entOrg.
6. Registrar los usuarios desde la pantalla de login. localhost:8080. 
	- Para admin: 
	admin@admin.com
	- Para organizador: 
		-organizador@organizador.com
		-organizador1@organizador.com
	- Para participantes: 
		-participante1@participante.com
		-participante2@participante.com
		-participante3@participante.com
		-participante4@participante.com
		-participante5@participante.com
		-participante6@participante.com
		-participante7@participante.com
		-participante8@participante.com
		-participante9@participante.com
		-participante10@participante.com						
7. Cambiar el tipo de usuario desde MySQL (1=admin, 2=organizador). Meter al menos 1 admin con id1, y 2 organizadores con id2 y id3 , respectivamente.
8. Cargar el script en MySQL: script_relleno_eventos.
9. Cargar el script en MySQL: script_relleno_gastos.
10. Cargar el script en MySQL: script_relleno_participantes.

Con esto ya se puede usar el programa Event Flow.