package com.example.eventFlow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
