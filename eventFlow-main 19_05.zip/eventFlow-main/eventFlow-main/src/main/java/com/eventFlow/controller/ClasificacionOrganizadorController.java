package com.eventFlow.controller;

import com.eventFlow.model.EnfrentamientoParticipante1vs1;
import com.eventFlow.model.EnfrentamientoParticipante2vs2;
import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.model.TipoClasificacion;
import com.eventFlow.model.ClasificacionGeneral;
import com.eventFlow.model.Club;
import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.TipoVersus;
import com.eventFlow.repository.ClasificacionGeneralRepository;
import com.eventFlow.repository.ClasificacionVersusRepository;
import com.eventFlow.repository.ClubRepository;
import com.eventFlow.repository.Enfrentamiento1vs1Repository;
import com.eventFlow.repository.Enfrentamiento2vs2Repository;
import com.eventFlow.repository.EnfrentamientoClubVsClubRepository;
import com.eventFlow.repository.EventoRepository;
import com.eventFlow.repository.ParticipanteRepository;
import com.eventFlow.repository.TipoClasificacionRepository;
import com.eventFlow.repository.TipoVersusRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/clasificacionesorganizador")
public class ClasificacionOrganizadorController {

    @Autowired
    private EventoRepository eventoRepo;

    @Autowired
    private TipoClasificacionRepository tipoClasificacionRepo;

    @Autowired
    private TipoVersusRepository tipoVersusRepo;

    @Autowired
    private ClasificacionGeneralRepository clasificacionGeneralRepo;

    @Autowired
    private ClasificacionVersusRepository clasificacionVersusRepo;

    @Autowired
    private ParticipanteRepository participanteRepo;

    @Autowired
    private Enfrentamiento1vs1Repository enfrentamientoRepo;
    
    @Autowired
    private Enfrentamiento2vs2Repository enfrentamiento2vs2Repo;
    
    @Autowired
    private EnfrentamientoClubVsClubRepository enfrentamientoClubRepo;

    @Autowired
    private ClubRepository clubRepo;



    @GetMapping
    public String mostrarEventosOrganizador(Model model, Principal principal) {
        String email = principal.getName();
        List<Evento> eventos = eventoRepo.findByCreadorEmail(email);
        model.addAttribute("eventos", eventos);
        return "clasificacionesorganizador";
    }

    @PostMapping("/seleccionar-evento")
    public String redirigirDesdeSelector(@RequestParam Long eventoId) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        if (evento != null) {
            if (evento.getTipoClasificacion() != null) {
                String tipoClasif = evento.getTipoClasificacion().getNombre();
                if (tipoClasif.equalsIgnoreCase("General")) {
                    return "redirect:/clasificacionesorganizador/general/" + eventoId;
                }
                if (tipoClasif.equalsIgnoreCase("Versus")) {
                    if (evento.getTipoVersus() != null) {
                        String tipoVersus = evento.getTipoVersus().getNombre();
                        String normalizado = tipoVersus.toLowerCase().replaceAll("[^a-z]", "");
                        if (normalizado.contains("clubvsclub")) {
                            return "redirect:/clasificacionesorganizador/club-vs-club/" + eventoId;
                        }
                        String ruta = tipoVersus.toLowerCase().replace(" ", "-");
                        return "redirect:/clasificacionesorganizador/versus-" + ruta + "/" + eventoId;
                    }
                    return "redirect:/clasificacionesorganizador/versus/" + eventoId;
                }
            }
            return "redirect:/clasificacionesorganizador/evento/" + eventoId + "/tipo";
        }
        return "redirect:/clasificacionesorganizador";
    }

    @GetMapping("/evento/{id}/tipo")
    public String seleccionarTipoClasificacion(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento != null && evento.getTipoClasificacion() != null) {
            return "redirect:/clasificacionesorganizador/seleccionar-evento";
        }
        model.addAttribute("evento", evento);
        model.addAttribute("tipos", tipoClasificacionRepo.findAll());
        return "seleccionar_tipo_clasificacion_organizador";
    }

    @PostMapping("/evento/{id}/guardar-tipo")
    public String guardarTipoClasificacion(@PathVariable Long id, @RequestParam("tipoId") Long tipoId) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        TipoClasificacion tipoSeleccionado = tipoClasificacionRepo.findById(tipoId).orElse(null);
        if (evento != null && tipoSeleccionado != null && evento.getTipoClasificacion() == null) {
            evento.setTipoClasificacion(tipoSeleccionado);
            eventoRepo.save(evento);
            if (tipoSeleccionado.getNombre().equalsIgnoreCase("Versus")) {
                return "redirect:/clasificacionesorganizador/versus/" + id;
            } else {
                return "redirect:/clasificacionesorganizador/general/" + id;
            }
        }
        return "redirect:/clasificacionesorganizador";
    }

    @GetMapping("/general/{id}")
    public String mostrarClasificacionGeneral(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/clasificacionesorganizador";

        List<ClasificacionGeneral> clasificados = ordenarClasificados(clasificacionGeneralRepo.findByEvento(evento));

        List<Participante> disponibles = participanteRepo.findByEvento(evento).stream()
            .filter(p -> clasificados.stream()
                .noneMatch(c -> c.getParticipante().getIdParticipante().equals(p.getIdParticipante())))
            .collect(Collectors.toList());

        model.addAttribute("evento", evento);
        model.addAttribute("clasificados", clasificados);
        model.addAttribute("disponibles", disponibles);
        model.addAttribute("editando", null);

        return "clasificacion_general_organizador";
    }


    @PostMapping("/general/{id}/guardar")
    public String guardarClasificadoGeneral(@PathVariable Long id,
                                            @RequestParam("participanteId") Long participanteId,
                                            @RequestParam("clasificado") boolean clasificado) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        Participante participante = participanteRepo.findById(participanteId).orElse(null);

        if (evento != null && participante != null) {
            ClasificacionGeneral nuevo = new ClasificacionGeneral();
            nuevo.setEvento(evento);
            nuevo.setParticipante(participante);
            nuevo.setClasificado(clasificado);
            if (clasificado) {
                Integer maxPos = clasificacionGeneralRepo.findMaxPosicionByEvento(evento);
                nuevo.setPosicion(maxPos != null ? maxPos + 1 : 1);
            }
            clasificacionGeneralRepo.save(nuevo);
        }
        return "redirect:/clasificacionesorganizador/general/" + id;
    }

    @GetMapping("/general/{eventoId}/editar/{clasificacionId}")
    public String editarClasificado(@PathVariable Long eventoId,
                                    @PathVariable Long clasificacionId,
                                    Model model) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        ClasificacionGeneral editando = clasificacionGeneralRepo.findById(clasificacionId).orElse(null);

        List<ClasificacionGeneral> clasificados = ordenarClasificados(clasificacionGeneralRepo.findByEvento(evento));

        List<Participante> disponibles = participanteRepo.findByEvento(evento).stream()
            .filter(p -> clasificados.stream()
                .noneMatch(c -> c.getParticipante().getIdParticipante().equals(p.getIdParticipante()))
                || p.getIdParticipante().equals(editando.getParticipante().getIdParticipante()))
            .collect(Collectors.toList());

        model.addAttribute("evento", evento);
        model.addAttribute("clasificados", clasificados);
        model.addAttribute("disponibles", disponibles);
        model.addAttribute("editando", editando);

        return "clasificacion_general_organizador";
    }


    @PostMapping("/general/{eventoId}/actualizar/{clasificacionId}")
    public String actualizarClasificado(@PathVariable Long eventoId,
                                        @PathVariable Long clasificacionId,
                                        @RequestParam Long participanteId,
                                        @RequestParam boolean clasificado) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        ClasificacionGeneral clasificacion = clasificacionGeneralRepo.findById(clasificacionId).orElse(null);

        if (evento == null || clasificacion == null) {
            return "redirect:/clasificacionesorganizador/general/" + eventoId;
        }

        boolean antesClasificado = clasificacion.isClasificado();
        clasificacion.setClasificado(clasificado);

        if (!clasificado && antesClasificado) {
            clasificacion.setPosicion(null);
        }

        if (clasificado && !antesClasificado) {
            Integer max = clasificacionGeneralRepo.findMaxPosicionByEvento(evento);
            clasificacion.setPosicion(max != null ? max + 1 : 1);
        }

        clasificacionGeneralRepo.save(clasificacion);

        // Reordenar después de cualquier cambio
        List<ClasificacionGeneral> clasificados = ordenarClasificados(clasificacionGeneralRepo.findByEvento(evento));
        int pos = 1;
        for (ClasificacionGeneral c : clasificados) {
            if (c.isClasificado()) {
                c.setPosicion(pos++);
            } else {
                c.setPosicion(null);
            }
        }
        clasificacionGeneralRepo.saveAll(clasificados);

        return "redirect:/clasificacionesorganizador/general/" + eventoId;
    }
    private List<ClasificacionGeneral> ordenarClasificados(List<ClasificacionGeneral> lista) {
        return lista.stream()
            .sorted((a, b) -> {
                if (a.getPosicion() == null && b.getPosicion() == null) return 0;
                if (a.getPosicion() == null) return 1;
                if (b.getPosicion() == null) return -1;
                return Integer.compare(a.getPosicion(), b.getPosicion());
            })
            .collect(Collectors.toList());
    }



    @GetMapping("/general/{eventoId}/eliminar/{clasificacionId}")
    public String eliminarClasificado(@PathVariable Long eventoId,
                                      @PathVariable Long clasificacionId) {
        clasificacionGeneralRepo.deleteById(clasificacionId);

        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        if (evento != null) {
            List<ClasificacionGeneral> clasificados = ordenarClasificados(clasificacionGeneralRepo.findByEvento(evento));
            int posicion = 1;
            for (ClasificacionGeneral c : clasificados) {
                if (c.isClasificado()) {
                    c.setPosicion(posicion++);
                } else {
                    c.setPosicion(null);
                }
            }
            clasificacionGeneralRepo.saveAll(clasificados);
        }

        return "redirect:/clasificacionesorganizador/general/" + eventoId;
    }


    @GetMapping("/versus/{id}")
    public String seleccionarSubtipoVersus(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento != null) {
            boolean yaTienePartidas = !clasificacionVersusRepo.findByEvento(evento).isEmpty();
            if (yaTienePartidas) {
                return "redirect:/clasificacionesorganizador/versus-participantes/" + evento.getIdEvento();
            }
            model.addAttribute("tiposVersus", tipoVersusRepo.findAll());
            model.addAttribute("evento", evento);
            return "seleccionar_tipo_versus_organizador";
        }
        return "redirect:/clasificacionesorganizador";
    }

    @PostMapping("/versus/{id}/tipo")
    public String guardarSubtipoVersus(@PathVariable Long id, @RequestParam("subtipo") String subtipo) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        TipoVersus tipoVersus = tipoVersusRepo.findByNombreIgnoreCase(subtipo);
        if (evento != null && tipoVersus != null) {
            evento.setTipoVersus(tipoVersus);
            eventoRepo.save(evento);
            String ruta = tipoVersus.getNombre().toLowerCase().replace(" ", "-");
            return "redirect:/clasificacionesorganizador/versus-" + ruta + "/" + id;
        }
        return "redirect:/clasificacionesorganizador/versus/" + id + "?error=tipoNoValido";
    }

    @GetMapping("/versus-1vs1/{id}")
    public String mostrarVersus1vs1Organizador(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/clasificacionesorganizador";
        List<Participante> participantes = participanteRepo.findByEvento(evento);
        List<EnfrentamientoParticipante1vs1> enfrentamientos = enfrentamientoRepo.findByEvento(evento);
        EnfrentamientoParticipante1vs1 nuevo = new EnfrentamientoParticipante1vs1();
        nuevo.setEvento(evento);
        model.addAttribute("evento", evento);
        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        model.addAttribute("nuevoEnfrentamiento", nuevo);
        return "versus_1vs1_organizador";
    }
    
    @PostMapping("/versus-1vs1/guardar")
    public String guardarEnfrentamiento1vs1(@RequestParam("evento.idEvento") Long eventoId,
                                            @RequestParam("participante1.idParticipante") Long participante1Id,
                                            @RequestParam("participante2.idParticipante") Long participante2Id,
                                            @RequestParam("resultadoJugador1") int resultadoJugador1,
                                            @RequestParam("resultadoJugador2") int resultadoJugador2,
                                            Model model) {

        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        Participante p1 = participanteRepo.findById(participante1Id).orElse(null);
        Participante p2 = participanteRepo.findById(participante2Id).orElse(null);

        if (evento == null || p1 == null || p2 == null || participante1Id.equals(participante2Id)) {
            model.addAttribute("error", "participantesIguales");
            return mostrarVersus1vs1Organizador(eventoId, model);
        }

        EnfrentamientoParticipante1vs1 enfrentamiento = new EnfrentamientoParticipante1vs1();
        enfrentamiento.setEvento(evento);
        enfrentamiento.setParticipante1(p1);
        enfrentamiento.setParticipante2(p2);
        enfrentamiento.setResultado(resultadoJugador1 + " - " + resultadoJugador2);

        enfrentamientoRepo.save(enfrentamiento);

        return mostrarVersus1vs1Organizador(eventoId, model);
    }

    	
    @GetMapping("/versus-1vs1/eliminar/{id}")
    public String eliminarEnfrentamiento1vs1(@PathVariable Long id,
                                             @RequestParam("eventoId") Long eventoId,
                                             Model model) {
        enfrentamientoRepo.deleteById(id);
        model.addAttribute("mensaje", "enfrentamientoEliminado");
        return mostrarVersus1vs1Organizador(eventoId, model);
    }
    	
    @GetMapping("/versus-2vs2/{id}")
    public String mostrarVersus2vs2Organizador(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/clasificacionesorganizador";

        List<Participante> participantes = participanteRepo.findByEvento(evento);
        List<EnfrentamientoParticipante2vs2> enfrentamientos = enfrentamiento2vs2Repo.findByEvento(evento);

        EnfrentamientoParticipante2vs2 nuevo = new EnfrentamientoParticipante2vs2();
        nuevo.setEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        model.addAttribute("nuevoEnfrentamiento", nuevo);

        return "versus_2vs2_organizador";
    }

    
    @PostMapping("/versus-2vs2/guardar")
    public String guardarEnfrentamiento2vs2(@RequestParam("evento.idEvento") Long eventoId,
                                            @RequestParam("participante1.idParticipante") Long participante1Id,
                                            @RequestParam("participante2.idParticipante") Long participante2Id,
                                            @RequestParam("participante3.idParticipante") Long participante3Id,
                                            @RequestParam("participante4.idParticipante") Long participante4Id,
                                            @RequestParam("resultadoEquipo1") int resultadoEquipo1,
                                            @RequestParam("resultadoEquipo2") int resultadoEquipo2,
                                            Model model) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        Participante p1a = participanteRepo.findById(participante1Id).orElse(null);
        Participante p1b = participanteRepo.findById(participante2Id).orElse(null);
        Participante p2a = participanteRepo.findById(participante3Id).orElse(null);
        Participante p2b = participanteRepo.findById(participante4Id).orElse(null);

        if (evento == null || p1a == null || p1b == null || p2a == null || p2b == null ||
            p1a.getIdParticipante().equals(p1b.getIdParticipante()) ||
            p2a.getIdParticipante().equals(p2b.getIdParticipante()) ||
            p1a.getIdParticipante().equals(p2a.getIdParticipante()) ||
            p1a.getIdParticipante().equals(p2b.getIdParticipante()) ||
            p1b.getIdParticipante().equals(p2a.getIdParticipante()) ||
            p1b.getIdParticipante().equals(p2b.getIdParticipante())) {

            model.addAttribute("error", "participantesIguales");
            return mostrarVersus2vs2Organizador(eventoId, model);
        }

        EnfrentamientoParticipante2vs2 enfrentamiento = new EnfrentamientoParticipante2vs2();
        enfrentamiento.setEvento(evento);
        enfrentamiento.setJugador1a(p1a);
        enfrentamiento.setJugador1b(p1b);
        enfrentamiento.setJugador2a(p2a);
        enfrentamiento.setJugador2b(p2b);
        enfrentamiento.setResultado(resultadoEquipo1 + " - " + resultadoEquipo2);

        enfrentamiento2vs2Repo.save(enfrentamiento);

        return mostrarVersus2vs2Organizador(eventoId, model);
    }


    
    @GetMapping("/versus-2vs2/eliminar/{id}")
    public String eliminarEnfrentamiento2vs2(@PathVariable Long id,
                                             @RequestParam("eventoId") Long eventoId,
                                             Model model) {
        enfrentamiento2vs2Repo.deleteById(id); // <- ESTE es el correcto
        model.addAttribute("mensaje", "enfrentamientoEliminado");
        return mostrarVersus2vs2Organizador(eventoId, model);
    }
    
    @GetMapping("/club-vs-club/{id}")
    public String mostrarVersusClubVsClub(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        if (evento == null) return "redirect:/clasificacionesorganizador";

        List<Club> clubes = participanteRepo.findDistinctClubByEvento(id); // ✅ corregido
        List<EnfrentamientoClubVsClub> enfrentamientos = enfrentamientoClubRepo.findByEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("clubes", clubes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        return "versus_clubvsclub_organizador";
    }

    
    @PostMapping("/club-vs-club/guardar")
    public String guardarEnfrentamientoClubVsClub(@RequestParam("evento.idEvento") Long eventoId,
                                                  @RequestParam("club1.idClub") Long club1Id,
                                                  @RequestParam("club2.idClub") Long club2Id,
                                                  @RequestParam("resultadoClub1") int resultadoClub1,
                                                  @RequestParam("resultadoClub2") int resultadoClub2,
                                                  Model model) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);
        Club club1 = clubRepo.findById(club1Id).orElse(null);
        Club club2 = clubRepo.findById(club2Id).orElse(null);

        if (evento == null || club1 == null || club2 == null || club1Id.equals(club2Id)) {
            model.addAttribute("error", "clubesIguales");
            return mostrarVersusClubVsClub(eventoId, model);
        }

        EnfrentamientoClubVsClub enfrentamiento = new EnfrentamientoClubVsClub();
        enfrentamiento.setEvento(evento);
        enfrentamiento.setClub1(club1);
        enfrentamiento.setClub2(club2);
        enfrentamiento.setResultado(resultadoClub1 + " - " + resultadoClub2);

        enfrentamientoClubRepo.save(enfrentamiento);

        return mostrarVersusClubVsClub(eventoId, model);
    }

    
    @GetMapping("/club-vs-club/eliminar/{id}")
    public String eliminarEnfrentamientoClubVsClub(@PathVariable Long id,
                                                   @RequestParam("eventoId") Long eventoId,
                                                   Model model) {
        enfrentamientoClubRepo.deleteById(id);
        model.addAttribute("mensaje", "enfrentamientoEliminado");
        return mostrarVersusClubVsClub(eventoId, model);
    }




}
