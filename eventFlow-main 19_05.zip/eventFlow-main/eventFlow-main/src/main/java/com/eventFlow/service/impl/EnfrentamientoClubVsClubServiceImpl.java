package com.eventFlow.service.impl;

import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.Evento;
import com.eventFlow.repository.EnfrentamientoClubVsClubRepository;
import com.eventFlow.service.EnfrentamientoClubVsClubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnfrentamientoClubVsClubServiceImpl implements EnfrentamientoClubVsClubService {

    @Autowired
    private EnfrentamientoClubVsClubRepository repo;

    @Override
    public void guardar(EnfrentamientoClubVsClub enfrentamiento) {
        repo.save(enfrentamiento);
    }

    @Override
    public void eliminar(Long id) {
        repo.deleteById(id);
    }

    @Override
    public List<EnfrentamientoClubVsClub> listarPorEvento(Evento evento) {
        return repo.findByEvento(evento);
    }
}
