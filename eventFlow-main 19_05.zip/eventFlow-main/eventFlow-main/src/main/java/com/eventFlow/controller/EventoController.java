package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Usuario;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.EntidadOrganizadoraService;
import com.eventFlow.service.LocalizacionService;
import com.eventFlow.service.UsuarioService;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/eventos")
public class EventoController {

    @Autowired
    private EventoService eventoService;

    @Autowired
    private EntidadOrganizadoraService entidadService;

    @Autowired
    private LocalizacionService localizacionService;
    
    @Autowired
    private UsuarioService usuarioService;


    @GetMapping
    public String listar(Model model) {
        model.addAttribute("eventos", eventoService.listarTodos());
        return "eventos";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, Principal principal) {
        model.addAttribute("evento", new Evento());
        model.addAttribute("entidades", entidadService.listarTodas());
        model.addAttribute("localizaciones", localizacionService.listarTodas());

        String email = principal.getName();
        Usuario usuario = usuarioService.findByEmail(email);

        // Para que un admin pueda seleccionar el creador desde el formulario
        if (usuario.getTipousuario() == 1) {
            model.addAttribute("usuarios", usuarioService.findAll()); // solo para el select si es admin
        } else {
            model.addAttribute("usuarios", null);
        }

        model.addAttribute("tipoUsuarioLogueado", usuario.getTipousuario()); // para usar en el HTML
        return "eventos_formulario";
    }


//    @PostMapping("/guardar")
//    public String guardar(@ModelAttribute("evento") Evento evento, Principal principal) {
//        if (evento.getCreador() == null || evento.getCreador().getIdusuario() == null) {
//            String email = principal.getName();
//            Usuario usuario = usuarioService.findByEmail(email);
//            evento.setCreador(usuario);
//        }
//        eventoService.guardar(evento);
//        return "redirect:/eventos";
//    }
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("evento") Evento evento, Principal principal) {
        if (evento.getCreador() == null || evento.getCreador().getIdusuario() == null) {
            String email = principal.getName();
            Usuario usuario = usuarioService.findByEmail(email);
            evento.setCreador(usuario);
        }

        eventoService.guardar(evento);

        // Redirección condicional según el tipo de usuario
        String email = principal.getName();
        Usuario usuario = usuarioService.findByEmail(email);
        
        if (usuario.getTipousuario() == 2) {
            return "redirect:/eventosorganizador"; // organizador
        } else {
            return "redirect:/eventos"; // admin
        }
    }


    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        eventoService.eliminar(id);
        return "redirect:/eventos";
    }
    
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, Principal principal) {
        Evento evento = eventoService.buscarPorId(id);
        if (evento != null) {
            model.addAttribute("evento", evento);
            model.addAttribute("entidades", entidadService.listarTodas());
            model.addAttribute("localizaciones", localizacionService.listarTodas());

            String email = principal.getName();
            Usuario usuario = usuarioService.findByEmail(email);

            if (usuario.getTipousuario() == 1) {
                model.addAttribute("usuarios", usuarioService.findAll());
            } else {
                model.addAttribute("usuarios", null);
            }

            model.addAttribute("tipoUsuarioLogueado", usuario.getTipousuario());

            return "eventos_formulario";
        } else {
            return "redirect:/eventos";
        }
    }
    
    @GetMapping("/editar-organizador/{id}")
    public String editarOrganizador(@PathVariable Long id, Model model, Principal principal) {
        Evento evento = eventoService.buscarPorId(id);
        if (evento != null) {
            model.addAttribute("evento", evento);
            model.addAttribute("entidades", entidadService.listarTodas());
            model.addAttribute("localizaciones", localizacionService.listarTodas());
            return "eventos_formulario_organizador";
        } else {
            return "redirect:/eventosorganizador";
        }
    }


    
    @GetMapping("/eventos/organizador")
    public String mostrarEventosDelOrganizador(Model model, Principal principal) {
        String email = principal.getName();  // Obtiene el email del usuario logueado
        List<Evento> eventos = eventoService.obtenerEventosDelUsuario(email);
        model.addAttribute("eventos", eventos);
        return "eventos/indexorganizador";
    }
    
    @GetMapping("/eventosorganizador")
    public String listarEventosDelOrganizador(Model model, Principal principal) {
        String email = principal.getName(); // este es el email del usuario logueado
        List<Evento> eventos = eventoService.obtenerEventosDelUsuario(email); // <- esto debe filtrar por email
        model.addAttribute("eventos", eventos);
        return "eventosorganizador";
    }



}
