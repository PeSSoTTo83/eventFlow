package com.eventFlow.model;

import jakarta.persistence.*;

@Entity
@Table(name = "localizaciones")
public class Localizacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLocalizacion;

    private String pais;
    private String provincia;
    private String municipio;

    @Column(name = "codigo_postal")
    private String codigoPostal;

    // NUEVOS CAMPOS
    private String direccionCompleta;
    private Double latitud;
    private Double longitud;

    @Column(length = 500)
    private String notas;

    // Getters y Setters
    public Long getIdLocalizacion() {
        return idLocalizacion;
    }

    public void setIdLocalizacion(Long idLocalizacion) {
        this.idLocalizacion = idLocalizacion;
    }

    public String getPais() {
        return pais != null ? pais : "";
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getProvincia() {
        return provincia != null ? provincia : "";
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getMunicipio() {
        return municipio != null ? municipio : "";
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getCodigoPostal() {
        return codigoPostal != null ? codigoPostal : "";
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getDireccionCompleta() {
        return direccionCompleta != null ? direccionCompleta : "";
    }

    public void setDireccionCompleta(String direccionCompleta) {
        this.direccionCompleta = direccionCompleta;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public String getNotas() {
        return notas != null ? notas : "";
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }
}
