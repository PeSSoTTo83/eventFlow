package com.eventFlow.repository;

import com.eventFlow.model.TipoVersus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoVersusRepository extends JpaRepository<TipoVersus, Long> {
    TipoVersus findByNombre(String nombre);
    TipoVersus findByNombreIgnoreCase(String nombre);

}
