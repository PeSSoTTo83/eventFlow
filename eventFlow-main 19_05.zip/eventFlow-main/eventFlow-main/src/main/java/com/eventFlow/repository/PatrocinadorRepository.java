package com.eventFlow.repository;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Patrocinador;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PatrocinadorRepository extends JpaRepository<Patrocinador, Long> {
	 List<Patrocinador> findByEvento(Evento evento);
}
