package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Usuario;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class EventoParticipanteController {

    @Autowired
    private EventoService eventoService;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/eventosparticipante")
    public String listarEventosDelParticipante(Model model, Principal principal) {
        String email = principal.getName(); // obtiene el email del participante logueado

        // Opcional: puedes obtener el usuario si lo necesitas
//        Usuario participante = usuarioService.obtenerUsuarioPorEmail(email);

        // Supón que hay un método para obtener los eventos a los que el participante está inscrito
        List<Evento> eventos = eventoService.obtenerEventosDeParticipante(email);

        eventos.forEach(e -> System.out.println("Evento: " + e.getNombre() + " | Participante: " + email));

        model.addAttribute("eventos", eventos);
        return "eventosparticipante";
    }
    
    @GetMapping("/eventosdisponibles")
    public String mostrarEventosParaInscripcion(Model model) {
        List<Evento> eventos = eventoService.listarEventosAbiertos(); // eventos abiertos
        model.addAttribute("eventos", eventos);
        return "eventosdisponibles"; // este será el nuevo HTML tipo listado
    }

}
