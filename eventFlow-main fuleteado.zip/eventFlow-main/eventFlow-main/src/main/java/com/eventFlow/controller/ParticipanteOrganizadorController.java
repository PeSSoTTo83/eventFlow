package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.model.Usuario;
import com.eventFlow.service.ClubService;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.ParticipanteService;
import com.eventFlow.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/participantesorganizador")
public class ParticipanteOrganizadorController {

    @Autowired
    private ParticipanteService participanteService;

    @Autowired
    private EventoService eventoService;

    @Autowired
    private ClubService clubService;

    @Autowired
    private UsuarioService usuarioService;

    // Paso 1: Mostrar solo eventos del organizador logueado
    @GetMapping
    public String seleccionarEventoOrganizador(Model model, Principal principal) {
        String email = principal.getName();
        Usuario usuario = usuarioService.findByEmail(email);

        List<Evento> eventos = eventoService.obtenerEventosDelUsuario(email);
        model.addAttribute("eventos", eventos);
        return "seleccionar_evento_organizador";
    }

    // Paso 2: Listar participantes de un evento específico del organizador
    @GetMapping("/evento/{id}")
    public String listarParticipantesEvento(@PathVariable Long id, Model model) {
        Evento evento = eventoService.buscarPorId(id);

        List<Participante> participantes = participanteService.listarTodos().stream()
                .filter(p -> p.getEvento().getIdEvento().equals(id))
                .toList();

        model.addAttribute("evento", evento);
        model.addAttribute("participantes", participantes);
        model.addAttribute("participante", new Participante());
        model.addAttribute("clubes", clubService.listarTodos());

        return "participantes_organizador";
    }

    @PostMapping("/guardar/{eventoId}")
    public String guardarParticipante(@ModelAttribute("participante") Participante participante,
                                      @PathVariable Long eventoId) {
        Evento evento = eventoService.buscarPorId(eventoId);
        participante.setEvento(evento);
        participanteService.guardar(participante);
        return "redirect:/participantesorganizador/evento/" + eventoId;
    }

    @GetMapping("/editar/{id}")
    public String editarParticipante(@PathVariable Long id, Model model) {
        Participante participante = participanteService.buscarPorId(id);
        Long eventoId = participante.getEvento().getIdEvento();

        model.addAttribute("evento", participante.getEvento());
        model.addAttribute("participante", participante);
        model.addAttribute("participantes", participanteService.listarTodos().stream()
                .filter(p -> p.getEvento().getIdEvento().equals(eventoId))
                .toList());
        model.addAttribute("clubes", clubService.listarTodos());

        return "participantes_organizador";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarParticipante(@PathVariable Long id) {
        Participante participante = participanteService.buscarPorId(id);
        Long eventoId = participante.getEvento().getIdEvento();

        participanteService.eliminar(id);
        return "redirect:/participantesorganizador/evento/" + eventoId;
    }
}
