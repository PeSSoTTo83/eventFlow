package com.eventFlow.repository;

import com.eventFlow.model.Club;
import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ParticipanteRepository extends JpaRepository<Participante, Long> {
    List<Participante> findByEvento(Evento evento);
    @Query("SELECT DISTINCT p.club FROM Participante p WHERE p.evento.idEvento = :idEvento AND p.club IS NOT NULL")
   
    List<Club> findDistinctClubByEvento(@Param("idEvento") Long idEvento);
 // ParticipanteRepository.java
    List<Participante> findByEventoIdEvento(Long idEvento);


    List<Participante> findByClubInAndEvento(List<Club> clubes, Evento evento);

    List<Participante> findByCorreo(String correo);
    boolean existsByCorreoAndEventoIdEvento(String correo, Long idEvento);

    @Query("SELECT p.evento.idEvento FROM Participante p WHERE p.correo = :correo")
    List<Long> findIdsEventosByCorreo(@Param("correo") String correo);

}
