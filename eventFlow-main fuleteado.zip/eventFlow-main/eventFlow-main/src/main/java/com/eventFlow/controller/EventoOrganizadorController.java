package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Usuario;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class EventoOrganizadorController {

    @Autowired
    private EventoService eventoService;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/eventosorganizador")
    public String listarEventosDelOrganizador(Model model, Principal principal) {
        String email = principal.getName(); // este es el email del usuario logueado
        List<Evento> eventos = eventoService.obtenerEventosDelUsuario(email);

        eventos.forEach(e -> System.out.println("Evento: " + e.getNombre() + " | Creador: " + e.getCreador().getEmail()));

        model.addAttribute("eventos", eventos);
        return "eventosorganizador";
    }
    @GetMapping("/eventos/eliminar-organizador/{id}")
    public String eliminarEventoOrganizador(@PathVariable Long id) {
        eventoService.eliminar(id);
        return "redirect:/eventosorganizador";
    }
    
    

}
