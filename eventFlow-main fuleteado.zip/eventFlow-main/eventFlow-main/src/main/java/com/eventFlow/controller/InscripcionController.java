package com.eventFlow.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.model.Usuario;
import com.eventFlow.repository.ClubRepository;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.ParticipanteService;
import com.eventFlow.service.UsuarioService;

import org.springframework.ui.Model;

@Controller
public class InscripcionController {

    @Autowired
    private EventoService eventoService;

    @Autowired
    private ParticipanteService participanteService;

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private ClubRepository clubRepository;


//    @GetMapping("/inscribirse/{idEvento}")
//    public String mostrarFormularioInscripcion(@PathVariable Long idEvento, Model model, Principal principal) {
//        Evento evento = eventoService.buscarPorId(idEvento);
//        Usuario usuario = usuarioService.findByEmail(principal.getName());
//
//        Participante participante = new Participante();
//        participante.setEvento(evento);
//        participante.setCorreo(usuario.getEmail());
//        participante.setNombre(usuario.getNombre());
//        participante.setApellidos(usuario.getApellido());
//
//        model.addAttribute("participante", participante);
//        model.addAttribute("clubes", clubRepository.findAll()); // 👍 Lista de clubes para el formulario
//        return "inscripcionparticipante";
//    }
    @GetMapping("/inscribirse/{idEvento}")
    public String mostrarFormularioInscripcion(@PathVariable Long idEvento, Model model, Principal principal) {
        Evento evento = eventoService.buscarPorId(idEvento);
        Usuario usuario = usuarioService.findByEmail(principal.getName());

        // 🔒 Validar si ya está inscrito
        boolean yaInscrito = participanteService.estaInscritoEnEvento(usuario.getEmail(), idEvento);
        if (yaInscrito) {
            return "redirect:/eventosparticipante?yaInscrito=true";
        }

        Participante participante = new Participante();
        participante.setEvento(evento);
        participante.setCorreo(usuario.getEmail());
        participante.setNombre(usuario.getNombre());
        participante.setApellidos(usuario.getApellido());

        model.addAttribute("participante", participante);
        model.addAttribute("clubes", clubRepository.findAll());
        return "inscripcionparticipante";
    }



    @PostMapping("/inscribirse")
    public String procesarInscripcion(@ModelAttribute Participante participante) {
        Evento evento = eventoService.buscarPorId(participante.getEvento().getIdEvento());
        participante.setEvento(evento); // evento ahora incluye al creador

        participanteService.guardar(participante);
        return "redirect:/eventosparticipante";
    }
    @GetMapping("/eventos-disponibles")
    public String verEventosDisponibles(Model model, Principal principal) {
        String email = principal.getName();
        List<Evento> eventos = eventoService.obtenerEventosDisponibles(email);
        List<Long> eventosInscritosIds = participanteService.obtenerIdsEventosInscritos(email);

        model.addAttribute("eventos", eventos);
        model.addAttribute("eventosInscritosIds", eventosInscritosIds);
        return "eventosdisponibles";
    }

}

