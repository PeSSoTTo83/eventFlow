package com.eventFlow.repository;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Usuario;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EventoRepository extends JpaRepository<Evento, Long> {
	List<Evento> findByCreadorEmail(String email);
//	List<Evento> findByParticipantesContaining(Usuario usuario);
	List<Evento> findByEstadoEvento(String estadoEvento);

	// Este método obtiene los IDs de los eventos en los que un usuario está inscrito, basado en su correo
	@Query("SELECT p.evento.idEvento FROM Participante p WHERE p.correo = :correo")
	List<Long> findIdsEventosByCorreo(String correo);

	// Este método busca todos los eventos con estado 'ABIERTO' excepto los que ya están en la lista de IDs
	List<Evento> findByIdEventoNotInAndEstadoEvento(List<Long> ids, String estadoEvento);



}
