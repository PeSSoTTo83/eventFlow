package com.eventFlow.controller;

import com.eventFlow.model.Evento;
import com.eventFlow.model.TipoClasificacion;
import com.eventFlow.model.TipoVersus;
import com.eventFlow.repository.ClasificacionVersusRepository;
import com.eventFlow.repository.EventoRepository;
import com.eventFlow.repository.TipoClasificacionRepository;
import com.eventFlow.repository.TipoVersusRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/clasificaciones")
public class ClasificacionController {

    @Autowired
    private TipoVersusRepository tipoVersusRepo;

    @Autowired
    private EventoRepository eventoRepo;

    @Autowired
    private TipoClasificacionRepository tipoClasificacionRepo;

    @Autowired
    private ClasificacionVersusRepository clasificacionVersusRepo;

    // 1. Mostrar todos los eventos
    @GetMapping
    public String seleccionarEvento(Model model) {
        List<Evento> eventos = eventoRepo.findAll();
        model.addAttribute("eventos", eventos);
        return "seleccionar_evento_clasificacion";
    }

    // 2. Selección del tipo de clasificación (General o Versus)
    @GetMapping("/evento/{id}/tipo")
    public String seleccionarTipoClasificacion(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);

        if (evento != null && evento.getTipoClasificacion() != null) {
            TipoClasificacion tipo = evento.getTipoClasificacion();

            // Redirigir a la página de clasificación general si ya tiene tipo general asignado
            if (tipo.getNombre().equalsIgnoreCase("General")) {
                return "redirect:/clasificaciones/general/" + evento.getIdEvento();
            } 

            // Si el tipo es "Versus" pero aún no tiene subtipo, redirigir a la selección de subtipo
            else if (tipo.getNombre().equalsIgnoreCase("Versus")) {
                if (evento.getTipoVersus() != null) {
                    String tipoVersus = evento.getTipoVersus().getNombre().toLowerCase().replace(" ", "-");
                    return "redirect:/clasificaciones/versus-" + tipoVersus + "/" + evento.getIdEvento();
                } else {
                    return "redirect:/clasificaciones/versus/" + evento.getIdEvento();
                }
            }
        }

        // Si no tiene tipo de clasificación, mostramos el formulario para elegir entre "General" o "Versus"
        List<TipoClasificacion> tipos = tipoClasificacionRepo.findAll();
        model.addAttribute("evento", evento);
        model.addAttribute("tipos", tipos);
        return "seleccionar_tipo_clasificacion";
    }

    // 3. Guardar tipo de clasificación
    @PostMapping("/evento/{id}/guardar-tipo")
    public String guardarTipoClasificacion(@PathVariable Long id, @RequestParam("tipoId") Long tipoId) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        TipoClasificacion tipoSeleccionado = tipoClasificacionRepo.findById(tipoId).orElse(null);

        if (evento != null && tipoSeleccionado != null && evento.getTipoClasificacion() == null) {
            evento.setTipoClasificacion(tipoSeleccionado);
            eventoRepo.save(evento);

            // Si seleccionas Versus, redirige a la página para elegir el subtipo
            if (tipoSeleccionado.getNombre().equalsIgnoreCase("Versus")) {
                return "redirect:/clasificaciones/versus/" + id;
            } else {
                // Si seleccionas General, redirige a la página de clasificación general
                return "redirect:/clasificaciones/general/" + id;
            }
        }

        return "redirect:/clasificaciones";
    }

    // 4. Seleccionar subtipo de Versus
    @GetMapping("/versus/{id}")
    public String seleccionarSubtipoVersus(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);

        if (evento != null) {
            boolean yaTienePartidas = !clasificacionVersusRepo.findByEvento(evento).isEmpty();
            if (yaTienePartidas) {
                return "redirect:/clasificaciones/versus-participantes/" + evento.getIdEvento();
            }

            List<TipoVersus> tiposVersus = tipoVersusRepo.findAll();
            model.addAttribute("tiposVersus", tiposVersus);
            model.addAttribute("evento", evento);
            return "seleccionar_tipo_versus";
        }

        return "redirect:/clasificaciones";
    }

    // 5. Guardar subtipo Versus y redirigir (CORREGIDO)
    @PostMapping("/versus/{id}/tipo")
    public String redirigirSegunSubtipo(@PathVariable Long id, @RequestParam("subtipo") String subtipo) {
        Evento evento = eventoRepo.findById(id).orElse(null);
        TipoVersus tipoVersus = tipoVersusRepo.findByNombreIgnoreCase(subtipo);

        if (evento != null && tipoVersus != null) {
            evento.setTipoVersus(tipoVersus);
            eventoRepo.save(evento);

            // ✅ Redirección específica para Club vs Club
            String tipoNormalizado = tipoVersus.getNombre().toLowerCase().replaceAll("[^a-z]", "");
            if (tipoNormalizado.contains("clubvsclub")) {
                return "redirect:/clasificaciones/club-vs-club/" + id;
            }

            // 🔄 Redirección genérica
            String ruta = tipoVersus.getNombre().toLowerCase().replace(" ", "-");
            return "redirect:/clasificaciones/versus-" + ruta + "/" + id;
        }

        return "redirect:/clasificaciones/versus/" + id + "?error=tipoNoValido";
    }

    
    @GetMapping("/versus-equipo-vs-equipo/{id}")
    public String mostrarClasificacionEquipoVsEquipo(@PathVariable Long id, Model model) {
        Evento evento = eventoRepo.findById(id).orElse(null);

        if (evento != null) {
            model.addAttribute("evento", evento);
            // Aquí puedes agregar lógica para traer equipos o resultados si es necesario.
            return "clasificacion_equipo_vs_equipo"; // archivo HTML Thymeleaf
        }

        return "redirect:/clasificaciones";
    }


    // 6. Redirección inicial desde el selector de eventos
    @PostMapping("/seleccionar-evento")
    public String redirigirDesdeSelector(@RequestParam Long eventoId) {
        Evento evento = eventoRepo.findById(eventoId).orElse(null);

        if (evento != null) {
            System.out.println("🎯 Evento encontrado: " + evento.getNombre());

            if (evento.getTipoClasificacion() != null) {
                System.out.println("📘 Tipo Clasificación: " + evento.getTipoClasificacion().getNombre());

                String tipoClasif = evento.getTipoClasificacion().getNombre();

                if (tipoClasif.equalsIgnoreCase("General")) {
                    return "redirect:/clasificaciones/general/" + eventoId;
                }

                if (tipoClasif.equalsIgnoreCase("Versus")) {
                    if (evento.getTipoVersus() != null) {
                        String tipoVersus = evento.getTipoVersus().getNombre();
                        System.out.println("📙 Tipo Versus: " + tipoVersus);

                        // ✅ COMPARACIÓN CORREGIDA
                        String normalizado = tipoVersus.toLowerCase().replaceAll("[^a-z]", "");
                        if (normalizado.contains("clubvsclub")) {
                            return "redirect:/clasificaciones/club-vs-club/" + eventoId;
                        }

                        String ruta = tipoVersus.toLowerCase().replace(" ", "-");
                        return "redirect:/clasificaciones/versus-" + ruta + "/" + eventoId;
                    }

                    return "redirect:/clasificaciones/versus/" + eventoId;
                }
            }

            return "redirect:/clasificaciones/evento/" + eventoId + "/tipo";
        }

        return "redirect:/clasificaciones";
    }




}
