package com.eventFlow.model;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "eventos")
public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEvento;

    private String nombre;
    private String deporte;           // Fútbol, Maratón, etc.
    private String categoriaEdad;     // Sub18, Senior
    private String genero;            // Masculino, Femenino, Mixto
    private String distancia;         // "42 km", "100 m"
    private String estadoEvento;      // Planificado, En Curso, Finalizado

    @Column(length = 1000)
    private String descripcion;

    private Double precioInscripcion;
    private String premio;

    @Column(length = 500)
    private String notasInternas;

    private Integer numParticipantes = 0;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaInicio;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaFin;

    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime horaInicio;

    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime horaFin;

    @ManyToOne
    @JoinColumn(name = "idEntidadOrganizadora")
    private EntidadOrganizadora entidadOrganizadora;

    @ManyToOne
    @JoinColumn(name = "idLocalizacion")
    private Localizacion localizacion;

    @ManyToOne
    @JoinColumn(name = "tipo_clasificacion_id")
    private TipoClasificacion tipoClasificacion;

    @ManyToOne
    @JoinColumn(name = "tipo_versus_id")
    private TipoVersus tipoVersus;
    
    @ManyToOne
    @JoinColumn(name = "creador_id", nullable = false)
    private Usuario creador;


    // ================= GETTERS & SETTERS ===================

    public Long getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(Long idEvento) {
        this.idEvento = idEvento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }

    public String getCategoriaEdad() {
        return categoriaEdad;
    }

    public void setCategoriaEdad(String categoriaEdad) {
        this.categoriaEdad = categoriaEdad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDistancia() {
        return distancia;
    }

    public void setDistancia(String distancia) {
        this.distancia = distancia;
    }

    public String getEstadoEvento() {
        return estadoEvento;
    }

    public void setEstadoEvento(String estadoEvento) {
        this.estadoEvento = estadoEvento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecioInscripcion() {
        return precioInscripcion;
    }

    public void setPrecioInscripcion(Double precioInscripcion) {
        this.precioInscripcion = precioInscripcion;
    }

    public String getPremio() {
        return premio;
    }

    public void setPremio(String premio) {
        this.premio = premio;
    }

    public String getNotasInternas() {
        return notasInternas;
    }

    public void setNotasInternas(String notasInternas) {
        this.notasInternas = notasInternas;
    }

    public Integer getNumParticipantes() {
        return numParticipantes;
    }

    public void setNumParticipantes(Integer numParticipantes) {
        this.numParticipantes = numParticipantes;
    }

    public void incrementarParticipantes() {
        this.numParticipantes++;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }

    public EntidadOrganizadora getEntidadOrganizadora() {
        return entidadOrganizadora;
    }

    public void setEntidadOrganizadora(EntidadOrganizadora entidadOrganizadora) {
        this.entidadOrganizadora = entidadOrganizadora;
    }

    public Localizacion getLocalizacion() {
        return localizacion;
    }

    public void setLocalizacion(Localizacion localizacion) {
        this.localizacion = localizacion;
    }

    public TipoClasificacion getTipoClasificacion() {
        return tipoClasificacion;
    }

    public void setTipoClasificacion(TipoClasificacion tipoClasificacion) {
        this.tipoClasificacion = tipoClasificacion;
    }

    public TipoVersus getTipoVersus() {
        return tipoVersus;
    }

    public void setTipoVersus(TipoVersus tipoVersus) {
        this.tipoVersus = tipoVersus;
    }

	public Usuario getCreador() {
		return creador;
	}

	public void setCreador(Usuario creador) {
		this.creador = creador;
	}
    
    
}
