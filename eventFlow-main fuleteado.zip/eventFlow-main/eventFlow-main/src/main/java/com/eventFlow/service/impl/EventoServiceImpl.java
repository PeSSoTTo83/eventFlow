package com.eventFlow.service.impl;

import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.model.Usuario;
import com.eventFlow.repository.EventoRepository;
import com.eventFlow.repository.ParticipanteRepository;
import com.eventFlow.repository.UsuarioRepo;
import com.eventFlow.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventoServiceImpl implements EventoService {

    @Autowired
    private EventoRepository repo;
    
    @Autowired
    private UsuarioRepo usuarioRepository;
    
    @Autowired
    private ParticipanteRepository participanteRepository;


    @Override
    public List<Evento> listarTodos() {
        return repo.findAll();
    }

    @Override
    public Evento buscarPorId(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Evento guardar(Evento evento) {
        if (evento.getPrecioInscripcion() == null) {
            evento.setPrecioInscripcion(0.0);
        }
        return repo.save(evento);
    }
    @Override
    public void eliminar(Long id) {
        repo.deleteById(id);
    }
    
    @Override
    public List<Evento> obtenerEventosDelUsuario(String email) {
        return repo.findByCreadorEmail(email);
    }
    @Override
    public List<Evento> obtenerEventosDeParticipante(String email) {
        List<Participante> registros = participanteRepository.findByCorreo(email);
        return registros.stream()
                        .map(Participante::getEvento)
                        .distinct()
                        .toList();
    }

    @Override
    public List<Evento> listarEventosAbiertos() {
        return repo.findByEstadoEvento("Planificado"); // o el estado que uses para eventos disponibles
    }
    @Override
    public List<Evento> obtenerEventosDisponibles(String email) {
        List<Long> inscritosIds = participanteRepository.findIdsEventosByCorreo(email);
        if (inscritosIds == null || inscritosIds.isEmpty()) {
        	return listarEventosAbiertos();
 // mostrar todos los abiertos si no hay ninguno inscrito
        }
        return repo.findByIdEventoNotInAndEstadoEvento(inscritosIds, "Planificado"); // o el valor exacto del estado

    }

}
