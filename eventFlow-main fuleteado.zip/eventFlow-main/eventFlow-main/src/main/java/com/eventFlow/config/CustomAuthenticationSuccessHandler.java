package com.eventFlow.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.eventFlow.model.Usuario;
import com.eventFlow.service.UsuarioService;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication)
            throws IOException, ServletException {

        // ⚠️ Spring Security guarda como username el email del usuario autenticado
        String email = authentication.getName();
        Usuario usuario = usuarioService.findByEmail(email); // ✅ usa el método por email

        if (usuario != null && usuario.getTipousuario() != null) {
            Long tipo = usuario.getTipousuario();

            if (tipo == 1) {
                response.sendRedirect(request.getContextPath() + "/index");
            } else if (tipo == 2) {
                response.sendRedirect(request.getContextPath() + "/indexorganizador");
            } else if (tipo == 3) {
                response.sendRedirect(request.getContextPath() + "/indexparticipante");
            } else {
                response.sendRedirect(request.getContextPath() + "/login?error=tipo");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/login?error=noUser");
        }
    }
}
