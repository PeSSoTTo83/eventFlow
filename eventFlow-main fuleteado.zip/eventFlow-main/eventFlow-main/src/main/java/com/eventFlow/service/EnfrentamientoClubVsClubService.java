package com.eventFlow.service;

import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.Evento;

import java.util.List;

public interface EnfrentamientoClubVsClubService {
    void guardar(EnfrentamientoClubVsClub enfrentamiento);
    void eliminar(Long id);
    List<EnfrentamientoClubVsClub> listarPorEvento(Evento evento);
    void eliminarPorId(Long id);
}
