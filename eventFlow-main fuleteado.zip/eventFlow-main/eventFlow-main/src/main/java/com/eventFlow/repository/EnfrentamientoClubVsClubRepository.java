package com.eventFlow.repository;

import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnfrentamientoClubVsClubRepository extends JpaRepository<EnfrentamientoClubVsClub, Long> {
    List<EnfrentamientoClubVsClub> findByEvento(Evento evento);
    
}
