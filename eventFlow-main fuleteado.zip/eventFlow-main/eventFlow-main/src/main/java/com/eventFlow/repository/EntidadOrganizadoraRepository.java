package com.eventFlow.repository;

import com.eventFlow.model.EntidadOrganizadora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntidadOrganizadoraRepository extends JpaRepository<EntidadOrganizadora, Long> {
}
