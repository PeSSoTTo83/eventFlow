package com.eventFlow.model;

import jakarta.persistence.*;

@Entity
@Table(name = "enfrentamiento_club_vs_club")
public class EnfrentamientoClubVsClub {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "club1_id")
    private Club club1;

    @ManyToOne
    @JoinColumn(name = "club2_id")
    private Club club2;

    private String resultado; // ejemplo: "3-2"

    @ManyToOne
    @JoinColumn(name = "evento_id")
    private Evento evento;

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Club getClub1() {
        return club1;
    }

    public void setClub1(Club club1) {
        this.club1 = club1;
    }

    public Club getClub2() {
        return club2;
    }

    public void setClub2(Club club2) {
        this.club2 = club2;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }
}
