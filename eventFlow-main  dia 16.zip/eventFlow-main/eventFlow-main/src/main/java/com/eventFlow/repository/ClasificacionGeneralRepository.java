package com.eventFlow.repository;

import com.eventFlow.model.ClasificacionGeneral;
import com.eventFlow.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ClasificacionGeneralRepository extends JpaRepository<ClasificacionGeneral, Long> {
    List<ClasificacionGeneral> findByEvento(Evento evento);
    
    List<ClasificacionGeneral> findByEventoOrderByPosicionAsc(Evento evento);

    @Query("SELECT MAX(c.posicion) FROM ClasificacionGeneral c WHERE c.evento = :evento")
    Integer findMaxPosicionByEvento(@Param("evento") Evento evento);

}
