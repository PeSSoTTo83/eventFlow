package com.eventFlow.repository;

import com.eventFlow.model.Federacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FederacionRepository extends JpaRepository<Federacion, Long> {
}
