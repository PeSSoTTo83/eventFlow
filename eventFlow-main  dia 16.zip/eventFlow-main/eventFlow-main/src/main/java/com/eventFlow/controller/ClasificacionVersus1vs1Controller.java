package com.eventFlow.controller;

import com.eventFlow.model.EnfrentamientoParticipante1vs1;
import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.service.Enfrentamiento1vs1Service;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.ParticipanteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/clasificaciones/versus-1vs1")
public class ClasificacionVersus1vs1Controller {

    @Autowired
    private EventoService eventoService;

    @Autowired
    private ParticipanteService participanteService;

    @Autowired
    private Enfrentamiento1vs1Service enfrentamientoService;

    @GetMapping("/{id}")
    public String mostrar(@PathVariable Long id, Model model) {
        Evento evento = eventoService.buscarPorId(id);
        List<Participante> participantes = participanteService.listarPorEvento(evento);
        List<EnfrentamientoParticipante1vs1> enfrentamientos = enfrentamientoService.listarPorEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        model.addAttribute("nuevoEnfrentamiento", new EnfrentamientoParticipante1vs1());

        return "versus_1vs1";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute EnfrentamientoParticipante1vs1 enfrentamiento,
                          @RequestParam("evento.idEvento") Long eventoId,
                          @RequestParam("resultadoJugador1") int resultadoJugador1,
                          @RequestParam("resultadoJugador2") int resultadoJugador2) {

        Evento evento = eventoService.buscarPorId(eventoId);

        if (evento != null) {
            // Validación: impedir participante contra sí mismo
            if (enfrentamiento.getParticipante1() != null &&
                enfrentamiento.getParticipante2() != null &&
                enfrentamiento.getParticipante1().getIdParticipante().equals(enfrentamiento.getParticipante2().getIdParticipante())) {
                // Redirige con error (esto puede mejorarse con un mensaje flash o Thymeleaf)
                return "redirect:/clasificaciones/versus-1vs1/" + eventoId + "?error=mismaPersona";
            }

            enfrentamiento.setEvento(evento);
            enfrentamiento.setResultado(resultadoJugador1 + "-" + resultadoJugador2);
            enfrentamientoService.guardar(enfrentamiento);
            return "redirect:/clasificaciones/versus-1vs1/" + eventoId;
        }

        return "redirect:/clasificaciones";
    }





    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        EnfrentamientoParticipante1vs1 enfrentamiento = enfrentamientoService.buscarPorId(id);
        Long eventoId = enfrentamiento.getEvento().getIdEvento();
        enfrentamientoService.eliminar(id);
        return "redirect:/clasificaciones/versus-1vs1/" + eventoId;
    }
}
