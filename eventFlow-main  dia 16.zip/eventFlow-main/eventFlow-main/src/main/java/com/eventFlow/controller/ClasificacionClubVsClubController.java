package com.eventFlow.controller;

import com.eventFlow.model.Club;
import com.eventFlow.model.EnfrentamientoClubVsClub;
import com.eventFlow.model.Evento;
import com.eventFlow.model.Participante;
import com.eventFlow.service.ClubService;
import com.eventFlow.service.EnfrentamientoClubVsClubService;
import com.eventFlow.service.EventoService;
import com.eventFlow.service.ParticipanteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/clasificaciones/club-vs-club")
public class ClasificacionClubVsClubController {

    @Autowired
    private ClubService clubService;

    @Autowired
    private EventoService eventoService;

    @Autowired
    private ParticipanteService participanteService;

    @Autowired
    private EnfrentamientoClubVsClubService enfrentamientoClubVsClubService;

    // 🔁 Método reutilizable para cargar datos
    private void cargarDatosEvento(Long idEvento, Model model, List<Long> clubIdsOptional) {
        Evento evento = eventoService.buscarPorId(idEvento);
        List<Club> clubes = participanteService.obtenerClubesConParticipantesEnEvento(idEvento);

        model.addAttribute("evento", evento);
        model.addAttribute("clubes", clubes);

        List<Club> seleccionados = (clubIdsOptional != null && !clubIdsOptional.isEmpty())
                ? clubService.buscarPorIds(clubIdsOptional)
                : clubes;

        List<Participante> participantes = participanteService.obtenerPorClubesYEvento(seleccionados, evento);

        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientoClubVsClubService.listarPorEvento(evento));
    }

    @GetMapping("/{idEvento}")
    public String mostrarVistaClasificacion(@PathVariable Long idEvento, Model model) {
        cargarDatosEvento(idEvento, model, null);
        return "clasificacion_equipo_vs_equipo";
    }

    @PostMapping("/{idEvento}/ver-clasificacion")
    public String verClasificacion(@PathVariable Long idEvento,
                                   @RequestParam("club1Id") Long club1Id,
                                   @RequestParam("club2Id") Long club2Id,
                                   Model model) {

        Evento evento = eventoService.buscarPorId(idEvento);

        List<Club> clubes = clubService.buscarPorIds(List.of(club1Id, club2Id));
        List<Participante> participantes = participanteService.obtenerPorClubesYEvento(clubes, evento);
        List<EnfrentamientoClubVsClub> enfrentamientos = enfrentamientoClubVsClubService.listarPorEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("clubes", clubes);
        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        model.addAttribute("mostrar", true);

        return "clasificacion_equipo_vs_equipo";
    }






    @PostMapping("/{idEvento}/guardar-enfrentamiento")
    public String guardarEnfrentamiento(@PathVariable Long idEvento,
                                        @RequestParam Long club1Id,
                                        @RequestParam Long club2Id,
                                        @RequestParam int resultadoClub1,
                                        @RequestParam int resultadoClub2,
                                        Model model) {

        Evento evento = eventoService.buscarPorId(idEvento);
        Club club1 = clubService.buscarPorId(club1Id);
        Club club2 = clubService.buscarPorId(club2Id);

        // Guardar enfrentamiento
        EnfrentamientoClubVsClub enfrentamiento = new EnfrentamientoClubVsClub();
        enfrentamiento.setEvento(evento);
        enfrentamiento.setClub1(club1);
        enfrentamiento.setClub2(club2);
        enfrentamiento.setResultado(resultadoClub1 + "-" + resultadoClub2);
        enfrentamientoClubVsClubService.guardar(enfrentamiento);

        // Recargar modelo para que la vista muestre todo como antes
        List<Club> clubes = participanteService.obtenerClubesConParticipantesEnEvento(idEvento);
        List<Participante> participantes = participanteService.obtenerPorClubesYEvento(clubes, evento);
        List<EnfrentamientoClubVsClub> enfrentamientos = enfrentamientoClubVsClubService.listarPorEvento(evento);

        model.addAttribute("evento", evento);
        model.addAttribute("clubes", clubes);
        model.addAttribute("participantes", participantes);
        model.addAttribute("enfrentamientos", enfrentamientos);
        model.addAttribute("mostrar", true); // <- ¡Esta línea es clave!

        return "clasificacion_equipo_vs_equipo";
    }

}
